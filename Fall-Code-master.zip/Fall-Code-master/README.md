# Fall-Code
Coding projects in the fall of 2019

contents
-Basic Java GUI
-Encrypter
-Messanger
-Graphing Calc
