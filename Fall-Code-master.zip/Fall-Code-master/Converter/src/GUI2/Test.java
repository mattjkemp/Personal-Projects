package GUI2;

public class Test {
	public static void main(String[] arg) {
		String currentDirectory = System.getProperty("user.dir");
		System.out.println("The current working directory is " + currentDirectory);

	}
}