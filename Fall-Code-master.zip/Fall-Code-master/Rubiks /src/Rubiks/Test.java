package Rubiks;

public class Test {
	public static void main(String[] args) {
		Cube testCube = new Cube();
		testCube.printCube();
		testCube.bottomLeft(1);
		testCube.printCube();
	}
}
