package TextComp;

public class Test {
	public static void main(String[] args) {
		double a = Interpreter.getPath("mi","ft", new Units());
		System.out.println(a);
	}
}
