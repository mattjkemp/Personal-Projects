Messanger is a local network private messanger that can be used to send 
private messages to another computer on the same network without any data being 
sent over the internet to ensure data safety. no messages are stored except when 
the program is open. You can run the program by executing the MessangerMac.jar or
MessangerWindows.jar

How to use:
To use the app you need to login, this process is open currently so you can create
an account by typing in a user and pass you wish for the account and clicking "Create" then 
click login this process can be closed so only specific accounts can log in to increase 
security, once you log in you can setup a connection between two computers by clicking
the + button in the top left. Once the the window pops up enter the local ipv4 address
of the computer you are trying to connect to and click add button underneath. This must be
done on both computers to see the the chat, although messages can be sent without both 
connections.

Bugs:
-on windows the send button is shifted to the top left of the actual send button(still works)
